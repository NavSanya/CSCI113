#include "Lab6BoothsMultiplyier.h"

bool BoothsMultiplyier::ALU1Bit(bool a, bool b, bool ci, bool Binv, bool result, bool* co)//only addition and subtraction
{
	
		if (Binv == 0)//addition condition
		{
			result = (a ^ b) ^ ci;
			*co = (a && b) || (ci && (a ^ b)) ;
		}
		else//subtraction condition--just do not b of the previous expressions
		{
			result = (a ^ (!b)) ^ ci;
			*co = (a && b) || (ci && (a ^ (!b)));
		}
		return result;
}

void BoothsMultiplyier::ALU16Bit(vector<bool>a, vector<bool>b, bool ci, bool op, vector<bool>& result, bool& co)
{

	for (int i = 0; i < 16; ++i)
	{
		result.at(i)=ALU1Bit(a.at(i), b.at(i), ci, op, result.at(i), &co);
		ci = co;
	}
	if ((ci ^ co) == 1)
	{
		cout << "Overflow sorry!!!";
	}
}

void BoothsMultiplyier::boothmul(vector<bool>n1, vector<bool>n2, vector<bool>& prod)
{
	vector<bool>MD = n1;
	vector<bool>MQ = n2;
	bool MQ_1 = 0;
	bool co;
	vector<bool>AC(16,0);//16 zeros in ac

	for (int cyclecount = 15; cyclecount >= 0; --cyclecount)
	{
		if (MQ[0] != MQ_1)
		{
			if (MQ[0] < MQ_1)
				ALU16Bit(MD, AC, 0, 0, AC, co);//add
			else
				ALU16Bit(MD, AC, 0, 1, AC, co);//sub
		}
		
		//shift AC and MQ together
			bool temp = AC[0];
			bool temp1 = AC[0];
			for (int i = 1; i < AC.size(); ++i)
			{
				AC.at(i-1)=AC.at(i);
				temp = AC.at(i);
			}
			temp = MQ[0];
			MQ.at(MQ.size()-1) = temp1;
			for (int i = 1; i < MQ.size(); ++i)
			{
				MQ.at(i - 1) = MQ.at(i);
				temp = MQ.at(i);
			}
			//combine AC and MQ
			prod = AC;
			for (int i = 1; i < MQ.size(); ++i)
			{
				prod.push_back(MQ.at(i));
			}
			
		
	}
}

int main()
{
	BoothsMultiplyier obj;
	vector<bool>a = { 0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1 };
	vector<bool>b = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0 };
	vector<bool>p;
	obj.boothmul(a, b, p);
	for (int i = 0; i < a.size(); ++i)
	{
		cout << a.at(i);
	}
	cout << endl;
	for (int i = 0; i < b.size(); ++i)
	{
		cout << b.at(i);
	}
	cout << endl;
	for (int i = 0; i < p.size(); ++i)
	{
		cout << p.at(i);
	}
	cout << endl;
	return 0;
}