#pragma once
#include<iostream>
#include<vector>
using namespace std;

class BoothsMultiplyier
{
public:
	//I will be using boolean values as the inpus and outputs
	bool ALU1Bit(bool a, bool b, bool ci, bool Binv, bool result, bool* co);//1 bit alu with 2 one bit inputs and 1 bit cin and 2 bit op
	void ALU16Bit(vector<bool>a, vector<bool>b, bool ci, bool op, vector<bool>& result, bool& co);//16bit vectors
	void boothmul(vector<bool>n1, vector<bool>n2, vector<bool>& prod);//16input 32outputs 
};